package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SafeSystemBridge
import com.example.model.ExecutionMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

    @Test
    fun `verify app name and ai calibration string resources`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("PUBG Booster", context.getString(R.string.app_name))
        assertEquals(
            "جاري معايرة الذكاء الاصطناعي",
            context.getString(R.string.ai_calibrating_notice)
        )
    }

    @Test
    fun `verify safety valve automatic fallback to safe mode when shizuku unavailable`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val bridge = SafeSystemBridge(context)
        val logs = mutableListOf<String>()

        val result = bridge.probeShizukuPermission { logs.add(it.detail) }
        assertEquals(ExecutionMode.SAFE_MODE, result.mode)
        assertTrue(logs.isNotEmpty())
    }
}

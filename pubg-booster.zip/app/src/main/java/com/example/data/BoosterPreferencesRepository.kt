package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.NeuralSyncMode
import com.example.model.VoltageProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.boosterDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "pubg_booster_2030_prefs"
)

data class SavedBoosterSettings(
    val hyperBoostActive: Boolean = false,
    val neuralReflexEnabled: Boolean = true,
    val quantumDnsEnabled: Boolean = true,
    val nanoThermalEnabled: Boolean = true,
    val holographicHudEnabled: Boolean = false,
    val hudStealthScreenshotShield: Boolean = true,
    val hudOpacity: Float = 0.78f,
    val neuralSyncMode: NeuralSyncMode = NeuralSyncMode.APEX_ZERO_LAG,
    val voltageProfile: VoltageProfile = VoltageProfile.BALANCED_MINUS_45MV
)

class BoosterPreferencesRepository(private val context: Context) {

    private object Keys {
        val HYPER_BOOST = booleanPreferencesKey("hyper_boost_active")
        val NEURAL_REFLEX = booleanPreferencesKey("neural_reflex_enabled")
        val QUANTUM_DNS = booleanPreferencesKey("quantum_dns_enabled")
        val NANO_THERMAL = booleanPreferencesKey("nano_thermal_enabled")
        val HOLOGRAPHIC_HUD = booleanPreferencesKey("holographic_hud_enabled")
        val HUD_STEALTH = booleanPreferencesKey("hud_stealth_screenshot_shield")
        val HUD_OPACITY = floatPreferencesKey("hud_opacity")
        val NEURAL_MODE = stringPreferencesKey("neural_sync_mode")
        val VOLTAGE_PROFILE = stringPreferencesKey("voltage_profile")
    }

    val settingsFlow: Flow<SavedBoosterSettings> = context.boosterDataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            val parsedNeuralMode = try {
                prefs[Keys.NEURAL_MODE]?.let { NeuralSyncMode.valueOf(it) }
                    ?: NeuralSyncMode.APEX_ZERO_LAG
            } catch (_: Throwable) {
                NeuralSyncMode.APEX_ZERO_LAG
            }

            val parsedVoltageProfile = try {
                prefs[Keys.VOLTAGE_PROFILE]?.let { VoltageProfile.valueOf(it) }
                    ?: VoltageProfile.BALANCED_MINUS_45MV
            } catch (_: Throwable) {
                VoltageProfile.BALANCED_MINUS_45MV
            }

            SavedBoosterSettings(
                hyperBoostActive = prefs[Keys.HYPER_BOOST] ?: false,
                neuralReflexEnabled = prefs[Keys.NEURAL_REFLEX] ?: true,
                quantumDnsEnabled = prefs[Keys.QUANTUM_DNS] ?: true,
                nanoThermalEnabled = prefs[Keys.NANO_THERMAL] ?: true,
                holographicHudEnabled = prefs[Keys.HOLOGRAPHIC_HUD] ?: false,
                hudStealthScreenshotShield = prefs[Keys.HUD_STEALTH] ?: true,
                hudOpacity = (prefs[Keys.HUD_OPACITY] ?: 0.78f).coerceIn(0.25f, 0.95f),
                neuralSyncMode = parsedNeuralMode,
                voltageProfile = parsedVoltageProfile
            )
        }

    suspend fun updateBoolean(keyName: String, value: Boolean) {
        try {
            context.boosterDataStore.edit { prefs ->
                when (keyName) {
                    "hyper_boost" -> prefs[Keys.HYPER_BOOST] = value
                    "neural_reflex" -> prefs[Keys.NEURAL_REFLEX] = value
                    "quantum_dns" -> prefs[Keys.QUANTUM_DNS] = value
                    "nano_thermal" -> prefs[Keys.NANO_THERMAL] = value
                    "holographic_hud" -> prefs[Keys.HOLOGRAPHIC_HUD] = value
                    "hud_stealth" -> prefs[Keys.HUD_STEALTH] = value
                }
            }
        } catch (_: Throwable) {
            // Protected by Safety Valve try-catch
        }
    }

    suspend fun updateHudOpacity(opacity: Float) {
        try {
            context.boosterDataStore.edit { prefs ->
                prefs[Keys.HUD_OPACITY] = opacity.coerceIn(0.25f, 0.95f)
            }
        } catch (_: Throwable) {
            // Protected by Safety Valve try-catch
        }
    }

    suspend fun updateNeuralMode(mode: NeuralSyncMode) {
        try {
            context.boosterDataStore.edit { prefs ->
                prefs[Keys.NEURAL_MODE] = mode.name
            }
        } catch (_: Throwable) {
            // Protected by Safety Valve try-catch
        }
    }

    suspend fun updateVoltageProfile(profile: VoltageProfile) {
        try {
            context.boosterDataStore.edit { prefs ->
                prefs[Keys.VOLTAGE_PROFILE] = profile.name
            }
        } catch (_: Throwable) {
            // Protected by Safety Valve try-catch
        }
    }
}

package com.example.model

enum class BoosterScreen {
    DASHBOARD,
    NEURAL_QUANTUM,
    THERMAL_SAFETY
}

enum class ExecutionMode {
    SHIZUKU_PRIVILEGED,
    SAFE_MODE
}

enum class NeuralSyncMode(val arabicLabel: String, val leadCompensationMs: Float) {
    TACTICAL("تكتيكي متزن", 4.2f),
    HYPER_PREDICTIVE("تنبؤ عصبي فائق", 8.6f),
    APEX_ZERO_LAG("صفر تأخير 2030", 12.4f)
}

enum class VoltageProfile(val arabicLabel: String, val deltaMv: Int, val coolingFactor: Float) {
    CRYO_MINUS_85MV("تبريد فائق (-85mV)", -85, 1.0f),
    BALANCED_MINUS_45MV("توازن نانوي (-45mV)", -45, 0.6f),
    APEX_LOCKED_0MV("أداء مطلق (0mV)", 0, 0.25f)
}

enum class BciArenaState {
    IDLE,
    WAITING_FOR_PULSE,
    PULSE_READY,
    COMPLETED,
    TOO_EARLY
}

data class DnsRouteNode(
    val id: String,
    val providerName: String,
    val ipAddress: String,
    val clusterCode: String,
    val latencyMs: Int,
    val jitterMs: Int,
    val distributionPercent: Int,
    val isOnline: Boolean
)

data class TelemetrySample(
    val tempCelsius: Float,
    val effectiveVoltageMv: Int,
    val fps: Int
)

data class SafetyLogEntry(
    val id: Long,
    val timeFormatted: String,
    val subsystem: String,
    val detail: String,
    val isSafetyFallback: Boolean
)

data class RadarBlip(
    val id: String,
    val code: String,
    val azimuthDeg: Float,
    val distanceNorm: Float,
    val elevationNorm: Float,
    val accentType: Int, // 0 = Red, 1 = Blue, 2 = Purple, 3 = Gold
    val metricValue: String
)

data class BoosterUiState(
    val currentScreen: BoosterScreen = BoosterScreen.DASHBOARD,
    val executionMode: ExecutionMode = ExecutionMode.SAFE_MODE,
    val shizukuStatusDetail: String = "تم التحويل تلقائياً إلى الوضع الآمن (Safe Mode)",
    val isAiHardwareSupported: Boolean = false,
    val isCalibratingAi: Boolean = true,
    val aiCalibrationProgress: Float = 0.35f,
    val aiCalibrationBannerVisible: Boolean = true,
    val aiLastCalibratedSecondsAgo: Int = 0,

    // Master & 4 Core 2030 Features
    val hyperBoostActive: Boolean = false,
    val neuralReflexEnabled: Boolean = true,
    val quantumDnsEnabled: Boolean = true,
    val nanoThermalEnabled: Boolean = true,
    val holographicHudEnabled: Boolean = false,
    val hudStealthScreenshotShield: Boolean = true,
    val hudOpacity: Float = 0.78f,
    val hudResetTrigger: Int = 0,

    // Modes
    val neuralSyncMode: NeuralSyncMode = NeuralSyncMode.APEX_ZERO_LAG,
    val voltageProfile: VoltageProfile = VoltageProfile.BALANCED_MINUS_45MV,

    // Live Hardware Telemetry
    val currentFps: Int = 60,
    val displayRefreshRateHz: Int = 60,
    val frameJitterMs: Float = 1.4f,
    val effectiveInputLagMs: Float = 0.4f,
    val batteryTempCelsius: Float = 33.5f,
    val rawBatteryVoltageMv: Int = 4120,
    val tunedVoltageMv: Int = 4075,
    val batteryPercent: Int = 85,
    val availableRamMb: Long = 4096L,
    val totalRamMb: Long = 8192L,
    val cpuCores: Int = 8,
    val networkTransportLabel: String = "Wi-Fi Quantum",
    val downstreamBandwidthMbps: Int = 120,
    val effectivePingMs: Int = 18,
    val isScanningDns: Boolean = false,
    val installedPubgPackage: String? = null,

    // Multi-path Quantum DNS Nodes
    val dnsNodes: List<DnsRouteNode> = emptyList(),

    // BCI Reflex Arena
    val bciArenaState: BciArenaState = BciArenaState.IDLE,
    val lastRawReflexMs: Float? = null,
    val lastSyncedDeltaMs: Float? = null,
    val bestSyncedDeltaMs: Float? = null,

    // History & Radar & Logs
    val telemetryHistory: List<TelemetrySample> = emptyList(),
    val radarBlips: List<RadarBlip> = emptyList(),
    val safetyLogs: List<SafetyLogEntry> = emptyList(),
    val corePerformanceScore: Int = 96
)

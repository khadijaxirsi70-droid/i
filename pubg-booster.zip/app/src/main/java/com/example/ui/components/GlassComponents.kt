package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ExecutionMode
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmberGold
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonElectricBlue
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TelemetryEmerald
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPlatinum
import com.example.ui.theme.TextSilver

fun luxuryQuadNeonBrush(): Brush = Brush.linearGradient(
    colors = listOf(
        NeonCrimson,
        NeonCyberPurple,
        NeonQuantumBlue,
        NeonMoltenGold
    )
)

@Composable
fun ObsidianGlassCard(
    modifier: Modifier = Modifier,
    primaryAccent: Color = NeonQuantumBlue,
    secondaryAccent: Color = NeonCyberPurple,
    cornerRadius: Dp = 24.dp,
    isHighlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val borderAlpha by animateFloatAsState(
        targetValue = if (isHighlighted) 0.78f else 0.34f,
        animationSpec = spring(),
        label = "glassBorderAlpha"
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            primaryAccent.copy(alpha = borderAlpha),
            Color.White.copy(alpha = 0.18f),
            secondaryAccent.copy(alpha = borderAlpha * 0.85f)
        )
    )

    val glassSurfaceBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = if (isHighlighted) 0.11f else 0.07f),
            ObsidianSurface.copy(alpha = 0.82f),
            primaryAccent.copy(alpha = if (isHighlighted) 0.10f else 0.04f)
        ),
        start = Offset(0f, 0f),
        end = Offset(700f, 700f)
    )

    val clickableModifier = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(ObsidianBlack.copy(alpha = 0.65f))
            .background(glassSurfaceBrush)
            .border(width = 1.2.dp, brush = borderBrush, shape = shape)
            .drawBehind {
                // Specular glass top hairline reflection
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.28f),
                            primaryAccent.copy(alpha = 0.35f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(size.width * 0.08f, 1.5f),
                    end = Offset(size.width * 0.92f, 1.5f),
                    strokeWidth = 2f
                )
            }
            .then(clickableModifier)
            .padding(18.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun SafeModeStatusPill(
    executionMode: ExecutionMode,
    onInspectSafetyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isSafeMode = executionMode == ExecutionMode.SAFE_MODE
    val accent = if (isSafeMode) NeonMoltenGold else TelemetryEmerald
    val shape = RoundedCornerShape(50)

    Surface(
        onClick = onInspectSafetyClick,
        shape = shape,
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.48f)),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("safe_mode_status_pill")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Icon(
                imageVector = if (isSafeMode) Icons.Filled.Shield else Icons.Filled.VerifiedUser,
                contentDescription = stringResource(R.string.safe_mode_active_badge),
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = if (isSafeMode) {
                    stringResource(R.string.safe_mode_active_badge)
                } else {
                    stringResource(R.string.shizuku_active_badge)
                },
                style = MaterialTheme.typography.labelLarge,
                color = TextPlatinum
            )
        }
    }
}

@Composable
fun AiCalibrationBanner(
    visible: Boolean,
    isCalibrating: Boolean,
    progress: Float,
    onRecalibrateClick: () -> Unit,
    onDismissClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pulseTransition = rememberInfiniteTransition(label = "aiBannerPulse")
    val glowAlpha by pulseTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.90f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aiGlow"
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        val shape = RoundedCornerShape(18.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            NeonCyberPurple.copy(alpha = 0.20f),
                            ObsidianSurface.copy(alpha = 0.92f),
                            NeonMoltenGold.copy(alpha = 0.16f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonMoltenGold.copy(alpha = if (isCalibrating) glowAlpha else 0.45f),
                            NeonCyberPurple.copy(alpha = 0.55f),
                            NeonQuantumBlue.copy(alpha = 0.45f)
                        )
                    ),
                    shape = shape
                )
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .testTag("ai_calibration_banner")
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCalibrating) {
                                    NeonMoltenGold.copy(alpha = 0.18f)
                                } else {
                                    TelemetryEmerald.copy(alpha = 0.18f)
                                }
                            )
                    ) {
                        Icon(
                            imageVector = if (isCalibrating) {
                                Icons.Filled.AutoAwesome
                            } else {
                                Icons.Filled.CheckCircle
                            },
                            contentDescription = stringResource(R.string.ai_calibrating_notice),
                            tint = if (isCalibrating) NeonMoltenGold else TelemetryEmerald,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isCalibrating) {
                                stringResource(R.string.ai_calibrating_notice)
                            } else {
                                stringResource(R.string.ai_calibrated_ready)
                            },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isCalibrating) NeonMoltenGold else TextPlatinum
                        )
                        Text(
                            text = if (isCalibrating) {
                                "مؤقت المعايرة التكيفي نشط لضبط مسارات الشبكة والانعكاس العصبي (${(progress * 100).toInt()}%)"
                            } else {
                                "نموذج المحاكاة العصبية والكمية يعمل باستقرار كامل"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSilver
                        )
                    }

                    if (!isCalibrating) {
                        IconButton(
                            onClick = onRecalibrateClick,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("recalibrate_ai_banner_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = stringResource(R.string.btn_recalibrate_ai),
                                tint = NeonQuantumBlue
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismissClick,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("dismiss_ai_banner_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "إخفاء الإشعار",
                            tint = TextMutedSteel
                        )
                    }
                }

                if (isCalibrating) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0.05f, 1f) },
                        color = NeonMoltenGold,
                        trackColor = Color.White.copy(alpha = 0.08f),
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }
            }
        }
    }
}

@Composable
fun BoosterModuleCard(
    title: String,
    description: String,
    metricBadge: String,
    subMetricBadge: String,
    icon: ImageVector,
    primaryAccent: Color,
    secondaryAccent: Color,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    onOpenDetails: () -> Unit,
    cardTag: String,
    switchTag: String,
    modifier: Modifier = Modifier
) {
    ObsidianGlassCard(
        primaryAccent = primaryAccent,
        secondaryAccent = secondaryAccent,
        isHighlighted = enabled,
        onClick = onOpenDetails,
        modifier = modifier.testTag(cardTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                primaryAccent.copy(alpha = 0.28f),
                                secondaryAccent.copy(alpha = 0.16f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = primaryAccent.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp)
                    )
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = primaryAccent,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPlatinum
                )
                Text(
                    text = subMetricBadge,
                    style = MaterialTheme.typography.labelSmall,
                    color = primaryAccent
                )
            }

            Switch(
                checked = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ObsidianBlack,
                    checkedTrackColor = primaryAccent,
                    uncheckedThumbColor = TextSilver,
                    uncheckedTrackColor = Color.White.copy(alpha = 0.12f),
                    uncheckedBorderColor = Color.White.copy(alpha = 0.24f)
                ),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag(switchTag)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = TextSilver
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(primaryAccent.copy(alpha = 0.14f))
                    .border(
                        width = 1.dp,
                        color = primaryAccent.copy(alpha = 0.36f),
                        shape = RoundedCornerShape(50)
                    )
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = metricBadge,
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = TextPlatinum
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "إعدادات متقدمة",
                    style = MaterialTheme.typography.labelLarge,
                    color = primaryAccent
                )
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = "فتح الإعدادات المتقدمة",
                    tint = primaryAccent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun TelemetryStatChip(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(
                width = 1.dp,
                color = accent.copy(alpha = 0.30f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            color = accent
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextMutedSteel
        )
    }
}

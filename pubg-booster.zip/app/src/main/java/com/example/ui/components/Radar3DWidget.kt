package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.RadarBlip
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPlatinum
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun Radar3DCard(
    blips: List<RadarBlip>,
    coreScore: Int,
    fps: Int,
    pingMs: Int,
    inputLagMs: Float,
    tempCelsius: Float,
    hyperBoostActive: Boolean,
    modifier: Modifier = Modifier
) {
    var yawOffsetDeg by remember { mutableFloatStateOf(18f) }
    var pitchRatio by remember { mutableFloatStateOf(0.52f) }

    val infiniteTransition = rememberInfiniteTransition(label = "radar3DTransition")
    val sweepAngleDeg by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (hyperBoostActive) 2400 else 4200,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarSweepDeg"
    )

    val hoverWave by infiniteTransition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "radarHoverWave"
    )

    val radarDesc = stringResource(R.string.cd_radar_canvas)

    ObsidianGlassCard(
        primaryAccent = if (hyperBoostActive) NeonMoltenGold else NeonQuantumBlue,
        secondaryAccent = NeonCrimson,
        isHighlighted = hyperBoostActive,
        modifier = modifier.testTag("radar_3d_card")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(NeonQuantumBlue.copy(alpha = 0.16f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Radar,
                        contentDescription = null,
                        tint = NeonQuantumBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.radar_section_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPlatinum
                    )
                    Text(
                        text = stringResource(R.string.radar_drag_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMutedSteel
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                NeonCrimson.copy(alpha = 0.24f),
                                NeonCyberPurple.copy(alpha = 0.24f),
                                NeonMoltenGold.copy(alpha = 0.24f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = NeonMoltenGold.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(50)
                    )
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "CORE $coreScore%",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = OrbitronFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = NeonMoltenGold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive 3D Perspective Radar Canvas
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxWidth()
                .height(235.dp)
                .semantics { contentDescription = radarDesc }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        yawOffsetDeg = (yawOffsetDeg + dragAmount.x * 0.45f) % 360f
                        pitchRatio = (pitchRatio + dragAmount.y * 0.0018f).coerceIn(0.34f, 0.76f)
                    }
                }
                .testTag("radar_3d_canvas")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val cx = w * 0.5f
                val cy = h * 0.57f
                val maxRx = min(w * 0.43f, h * 0.62f)
                val maxRy = maxRx * pitchRatio
                val maxElevationPx = h * 0.28f

                // Ambient 3D Holographic Dome Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonQuantumBlue.copy(alpha = 0.18f),
                            NeonCyberPurple.copy(alpha = 0.11f),
                            NeonCrimson.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy - maxElevationPx * 0.25f),
                        radius = maxRx * 1.15f
                    ),
                    radius = maxRx * 1.15f,
                    center = Offset(cx, cy - maxElevationPx * 0.25f)
                )

                // Helper to project 3D polar (radiusNorm, angleDeg, zElevationPx) onto 2D Canvas
                fun project3D(rNorm: Float, deg: Float, zPx: Float): Offset {
                    val rad = ((deg + yawOffsetDeg) * PI / 180.0)
                    val x = cx + (cos(rad).toFloat() * maxRx * rNorm)
                    val y = cy + (sin(rad).toFloat() * maxRy * rNorm) - zPx
                    return Offset(x, y)
                }

                // Draw lower holographic shadow ring for 3D depth
                val subFloorY = cy + 16f
                drawOval(
                    color = NeonCyberPurple.copy(alpha = 0.18f),
                    topLeft = Offset(cx - maxRx * 0.92f, subFloorY - maxRy * 0.92f),
                    size = Size(maxRx * 1.84f, maxRy * 1.84f),
                    style = Stroke(width = 1.5f)
                )

                // Draw 4 concentric 3D elliptical rings at progressive z-bowl depth
                val ringSteps = listOf(1.0f, 0.75f, 0.50f, 0.25f)
                ringSteps.forEachIndexed { idx, rNorm ->
                    val ringZ = (1f - rNorm) * (10f + hoverWave * 2.5f)
                    val rx = maxRx * rNorm
                    val ry = maxRy * rNorm
                    val ringColor = when (idx) {
                        0 -> NeonQuantumBlue.copy(alpha = 0.55f)
                        1 -> NeonCyberPurple.copy(alpha = 0.42f)
                        2 -> NeonCrimson.copy(alpha = 0.36f)
                        else -> NeonMoltenGold.copy(alpha = 0.50f)
                    }
                    drawOval(
                        color = ringColor,
                        topLeft = Offset(cx - rx, (cy - ringZ) - ry),
                        size = Size(rx * 2f, ry * 2f),
                        style = Stroke(width = if (idx == 0) 2.4f else 1.4f)
                    )
                }

                // Upper holographic crown ring floating in 3D space
                val crownRx = maxRx * 0.56f
                val crownRy = maxRy * 0.56f
                val crownZ = maxElevationPx * 0.72f
                drawOval(
                    color = NeonMoltenGold.copy(alpha = 0.24f),
                    topLeft = Offset(cx - crownRx, (cy - crownZ) - crownRy),
                    size = Size(crownRx * 2f, crownRy * 2f),
                    style = Stroke(width = 1.2f)
                )

                // 8 Azimuth 3D Grid Meridians + 3D Dome Struts
                for (spoke in 0 until 8) {
                    val spokeAngle = spoke * 45f
                    val outerPt = project3D(1.0f, spokeAngle, 0f)
                    val centerPt = project3D(0f, spokeAngle, 12f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.12f),
                        start = centerPt,
                        end = outerPt,
                        strokeWidth = 1.1f
                    )
                    if (spoke % 2 == 0) {
                        val crownPt = project3D(0.56f, spokeAngle, crownZ)
                        drawLine(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    NeonQuantumBlue.copy(alpha = 0.30f),
                                    NeonMoltenGold.copy(alpha = 0.18f)
                                ),
                                start = outerPt,
                                end = crownPt
                            ),
                            start = outerPt,
                            end = crownPt,
                            strokeWidth = 1.2f
                        )
                    }
                }

                // Volumetric 3D Rotating Sweep Trail (18 phosphor fan slices)
                val trailSlices = 18
                for (s in 0 until trailSlices) {
                    val sliceDeg = sweepAngleDeg - (s * 2.6f)
                    val nextDeg = sliceDeg - 2.8f
                    val p0 = Offset(cx, cy - 10f)
                    val p1 = project3D(1.0f, sliceDeg, 0f)
                    val p2 = project3D(1.0f, nextDeg, 0f)
                    val alpha = ((trailSlices - s).toFloat() / trailSlices) * 0.22f
                    val sweepPath = Path().apply {
                        moveTo(p0.x, p0.y)
                        lineTo(p1.x, p1.y)
                        lineTo(p2.x, p2.y)
                        close()
                    }
                    drawPath(
                        path = sweepPath,
                        color = if (hyperBoostActive) {
                            NeonMoltenGold.copy(alpha = alpha)
                        } else {
                            NeonQuantumBlue.copy(alpha = alpha)
                        }
                    )
                }

                // Leading Laser Sweep Beam
                val leadTip = project3D(1.02f, sweepAngleDeg, 0f)
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            NeonMoltenGold,
                            NeonQuantumBlue
                        ),
                        start = Offset(cx, cy - 10f),
                        end = leadTip
                    ),
                    start = Offset(cx, cy - 10f),
                    end = leadTip,
                    strokeWidth = 3.0f,
                    cap = StrokeCap.Round
                )

                // 3D Elevation Stalks & Neon Telemetry Orbs
                blips.forEach { blip ->
                    val blipColor = when (blip.accentType) {
                        0 -> NeonCrimson
                        1 -> NeonQuantumBlue
                        2 -> NeonCyberPurple
                        else -> NeonMoltenGold
                    }
                    val zHeight = blip.elevationNorm * maxElevationPx
                    val floorPt = project3D(blip.distanceNorm, blip.azimuthDeg, 0f)
                    val elevatedPt = project3D(blip.distanceNorm, blip.azimuthDeg, zHeight)

                    // Base ring on radar floor
                    drawOval(
                        color = blipColor.copy(alpha = 0.50f),
                        topLeft = Offset(floorPt.x - 7f, floorPt.y - 3.5f),
                        size = Size(14f, 7f),
                        style = Stroke(width = 1.5f)
                    )

                    // Vertical 3D laser stalk
                    drawLine(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                blipColor,
                                blipColor.copy(alpha = 0.20f)
                            ),
                            startY = elevatedPt.y,
                            endY = floorPt.y
                        ),
                        start = floorPt,
                        end = elevatedPt,
                        strokeWidth = 2.2f,
                        cap = StrokeCap.Round
                    )

                    // Glowing 3D node halo + solid core
                    drawCircle(
                        color = blipColor.copy(alpha = 0.30f),
                        radius = 12f,
                        center = elevatedPt
                    )
                    drawCircle(
                        color = blipColor,
                        radius = 5.2f,
                        center = elevatedPt
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.2f,
                        center = elevatedPt
                    )
                }

                // Central 3D Quantum Singularity Core
                val apexCenter = Offset(cx, cy - 12f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonMoltenGold.copy(alpha = 0.65f),
                            NeonCrimson.copy(alpha = 0.30f),
                            Color.Transparent
                        ),
                        center = apexCenter,
                        radius = 24f
                    ),
                    radius = 24f,
                    center = apexCenter
                )
                drawCircle(
                    color = TextPlatinum,
                    radius = 5f,
                    center = apexCenter
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Bottom Telemetry Bar under 3D Radar
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            TelemetryStatChip(
                label = "الإطارات",
                value = "$fps FPS",
                accent = NeonQuantumBlue,
                modifier = Modifier.weight(1f)
            )
            TelemetryStatChip(
                label = "البينج الكمي",
                value = "${pingMs}ms",
                accent = NeonCyberPurple,
                modifier = Modifier.weight(1f)
            )
            TelemetryStatChip(
                label = "استجابة BCI",
                value = "${inputLagMs}ms",
                accent = NeonMoltenGold,
                modifier = Modifier.weight(1f)
            )
            TelemetryStatChip(
                label = "الحرارة",
                value = "${"%.1f".format(tempCelsius)}°C",
                accent = NeonCrimson,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BoosterUiState
import com.example.model.ExecutionMode
import com.example.model.SafetyLogEntry
import com.example.model.TelemetrySample
import com.example.model.VoltageProfile
import com.example.ui.components.ObsidianGlassCard
import com.example.ui.components.TelemetryStatChip
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TelemetryEmerald
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPlatinum
import com.example.ui.theme.TextSilver

@Composable
fun ThermalSafetyScreen(
    uiState: BoosterUiState,
    onBackToDashboard: () -> Unit,
    onSelectVoltageProfile: (VoltageProfile) -> Unit,
    onToggleHud: (Boolean) -> Unit,
    onToggleHudStealth: (Boolean) -> Unit,
    onChangeHudOpacity: (Float) -> Unit,
    onResetHudPosition: () -> Unit,
    onRecheckSafetyValve: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToDashboard)

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("thermal_safety_screen_list")
    ) {
        // Section 1: Nano-Thermal Shield & Dynamic Voltage Curve
        item {
            ObsidianGlassCard(
                primaryAccent = NeonCrimson,
                secondaryAccent = NeonMoltenGold,
                isHighlighted = uiState.nanoThermalEnabled
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeviceThermostat,
                        contentDescription = null,
                        tint = NeonCrimson,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = stringResource(R.string.feature_thermal_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPlatinum
                        )
                        Text(
                            text = stringResource(R.string.voltage_curve_title),
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonMoltenGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TelemetryStatChip(
                        label = "حرارة العتاد",
                        value = "${"%.1f".format(uiState.batteryTempCelsius)}°C",
                        accent = NeonCrimson,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatChip(
                        label = "الفولتية الخام",
                        value = "${uiState.rawBatteryVoltageMv}mV",
                        accent = TextSilver,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatChip(
                        label = "فولتية النانو",
                        value = "${uiState.tunedVoltageMv}mV",
                        accent = NeonMoltenGold,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Voltage Profile Selector
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    VoltageProfile.entries.forEach { profile ->
                        val selected = uiState.voltageProfile == profile
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectVoltageProfile(profile) },
                            label = {
                                Text(
                                    text = profile.arabicLabel,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCrimson.copy(alpha = 0.24f),
                                selectedLabelColor = NeonMoltenGold,
                                containerColor = Color.White.copy(alpha = 0.05f),
                                labelColor = TextSilver
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("voltage_profile_${profile.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = stringResource(R.string.thermal_chart_title),
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPlatinum
                )

                Spacer(modifier = Modifier.height(8.dp))

                ThermalVoltageOscilloscope(
                    samples = uiState.telemetryHistory,
                    currentTemp = uiState.batteryTempCelsius,
                    currentVolt = uiState.tunedVoltageMv
                )
            }
        }

        // Section 2: Holographic HUD & Screenshot Stealth Shield (FLAG_SECURE)
        item {
            ObsidianGlassCard(
                primaryAccent = NeonCyberPurple,
                secondaryAccent = NeonQuantumBlue,
                isHighlighted = uiState.holographicHudEnabled
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ViewInAr,
                            contentDescription = null,
                            tint = NeonCyberPurple,
                            modifier = Modifier.size(26.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.feature_hud_title),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPlatinum
                            )
                            Text(
                                text = "لوحة قياس شفافة قابلة للسحب في أي مكان",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonQuantumBlue
                            )
                        }
                    }

                    Switch(
                        checked = uiState.holographicHudEnabled,
                        onCheckedChange = onToggleHud,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianBlack,
                            checkedTrackColor = NeonCyberPurple
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("thermal_screen_hud_switch")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Screenshot Stealth Toggle (FLAG_SECURE)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.hud_stealth_toggle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPlatinum,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = uiState.hudStealthScreenshotShield,
                        onCheckedChange = onToggleHudStealth,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ObsidianBlack,
                            checkedTrackColor = NeonMoltenGold
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hud_stealth_switch")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = stringResource(R.string.hud_opacity_label),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSilver
                    )
                    Text(
                        text = "${(uiState.hudOpacity * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = NeonQuantumBlue
                    )
                }

                Slider(
                    value = uiState.hudOpacity,
                    onValueChange = onChangeHudOpacity,
                    valueRange = 0.25f..0.95f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonQuantumBlue,
                        activeTrackColor = NeonCyberPurple
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hud_opacity_slider")
                )

                OutlinedButton(
                    onClick = onResetHudPosition,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("reset_hud_pos_button")
                ) {
                    Text(
                        text = stringResource(R.string.hud_reset_position),
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonQuantumBlue
                    )
                }
            }
        }

        // Section 3: Error Engineering & Safety Valve Console (صمام الأمان)
        item {
            ObsidianGlassCard(
                primaryAccent = NeonMoltenGold,
                secondaryAccent = TelemetryEmerald,
                isHighlighted = true
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.HealthAndSafety,
                        contentDescription = null,
                        tint = NeonMoltenGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = stringResource(R.string.safety_valve_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPlatinum
                        )
                        Text(
                            text = uiState.shizukuStatusDetail,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (uiState.executionMode == ExecutionMode.SAFE_MODE) {
                                NeonMoltenGold
                            } else {
                                TelemetryEmerald
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = stringResource(R.string.safety_shizuku_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSilver
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.safety_ai_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSilver
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onRecheckSafetyValve,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonMoltenGold,
                        contentColor = ObsidianBlack
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("recheck_shizuku_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_recheck_shizuku),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = stringResource(R.string.safety_log_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPlatinum
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    uiState.safetyLogs.take(8).forEach { entry ->
                        SafetyLogRow(entry = entry)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ThermalVoltageOscilloscope(
    samples: List<TelemetrySample>,
    currentTemp: Float,
    currentVolt: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(ObsidianBlack.copy(alpha = 0.78f))
            .border(
                width = 1.dp,
                color = NeonCrimson.copy(alpha = 0.35f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(10.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Grid lines
            for (r in 1..3) {
                val y = h * (r / 4f)
                drawLine(
                    color = Color.White.copy(alpha = 0.07f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            val plotSamples = if (samples.size >= 2) {
                samples
            } else {
                List(8) { TelemetrySample(currentTemp, currentVolt, 60) }
            }

            val tempPath = Path()
            val voltPath = Path()

            plotSamples.forEachIndexed { idx, s ->
                val x = (idx.toFloat() / (plotSamples.size - 1).coerceAtLeast(1)) * w
                val normTemp = ((s.tempCelsius - 20f) / 35f).coerceIn(0.08f, 0.92f)
                val yTemp = h * (1f - normTemp)

                val normVolt = ((s.effectiveVoltageMv - 3600f) / 800f).coerceIn(0.08f, 0.92f)
                val yVolt = h * (1f - normVolt)

                if (idx == 0) {
                    tempPath.moveTo(x, yTemp)
                    voltPath.moveTo(x, yVolt)
                } else {
                    tempPath.lineTo(x, yTemp)
                    voltPath.lineTo(x, yVolt)
                }
            }

            drawPath(
                path = tempPath,
                brush = Brush.horizontalGradient(listOf(NeonCrimson, NeonMoltenGold)),
                style = Stroke(width = 3.2f, cap = StrokeCap.Round)
            )

            drawPath(
                path = voltPath,
                brush = Brush.horizontalGradient(listOf(NeonQuantumBlue, NeonCyberPurple)),
                style = Stroke(width = 2.4f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun SafetyLogRow(entry: SafetyLogEntry) {
    val accent = if (entry.isSafetyFallback) NeonMoltenGold else TelemetryEmerald
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.03f))
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text = "[${entry.timeFormatted}]",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = JetBrainsMonoFontFamily,
            color = TextMutedSteel
        )
        Text(
            text = entry.subsystem,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            color = accent
        )
        Text(
            text = entry.detail,
            style = MaterialTheme.typography.bodySmall,
            color = TextSilver,
            modifier = Modifier.weight(1f)
        )
    }
}

package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPlatinum
import kotlin.math.roundToInt

@Composable
fun HolographicHudOverlay(
    visible: Boolean,
    opacity: Float,
    stealthScreenshotActive: Boolean,
    resetTrigger: Int,
    fps: Int,
    pingMs: Int,
    inputLagMs: Float,
    tempCelsius: Float,
    voltageMv: Int,
    onCloseHud: () -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var isCompactPill by remember { mutableStateOf(false) }

    LaunchedEffect(resetTrigger) {
        offsetX = 0f
        offsetY = 0f
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(),
        exit = fadeOut() + scaleOut(),
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX = (offsetX + dragAmount.x).coerceIn(-450f, 450f)
                    offsetY = (offsetY + dragAmount.y).coerceIn(-650f, 650f)
                }
            }
            .testTag("floating_holographic_hud")
    ) {
        val shape = RoundedCornerShape(22.dp)
        val glassAlpha = (opacity * 0.42f).coerceIn(0.10f, 0.55f)
        val borderAlpha = (opacity * 0.85f).coerceIn(0.35f, 0.95f)

        Box(
            modifier = Modifier
                .clip(shape)
                .background(ObsidianBlack.copy(alpha = glassAlpha))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            NeonQuantumBlue.copy(alpha = 0.14f * opacity),
                            Color.White.copy(alpha = 0.06f * opacity),
                            NeonCyberPurple.copy(alpha = 0.14f * opacity)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonQuantumBlue.copy(alpha = borderAlpha),
                            NeonMoltenGold.copy(alpha = borderAlpha),
                            NeonCrimson.copy(alpha = borderAlpha)
                        )
                    ),
                    shape = shape
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NeonQuantumBlue)
                    )
                    Text(
                        text = "HOLO-HUD // 2030",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = NeonQuantumBlue
                    )

                    if (stealthScreenshotActive) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(NeonMoltenGold.copy(alpha = 0.18f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VisibilityOff,
                                contentDescription = "مخفي من لقطات الشاشة",
                                tint = NeonMoltenGold,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "مخفي",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonMoltenGold
                            )
                        }
                    }

                    IconButton(
                        onClick = { isCompactPill = !isCompactPill },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .size(36.dp)
                            .testTag("hud_toggle_size_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.OpenInFull,
                            contentDescription = stringResource(R.string.cd_expand_hud),
                            tint = TextPlatinum,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    IconButton(
                        onClick = onCloseHud,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .size(36.dp)
                            .testTag("hud_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = stringResource(R.string.cd_close_hud),
                            tint = NeonCrimson,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                if (!isCompactPill) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HudMiniMetric("FPS", "$fps", NeonQuantumBlue)
                        HudMiniMetric("PING", "${pingMs}ms", NeonCyberPurple)
                        HudMiniMetric("BCI", "${inputLagMs}ms", NeonMoltenGold)
                        HudMiniMetric("TEMP", "${"%.0f".format(tempCelsius)}°", NeonCrimson)
                        HudMiniMetric("VOLT", "${voltageMv}mV", TextPlatinum)
                    }
                }
            }
        }
    }
}

@Composable
private fun HudMiniMetric(
    label: String,
    value: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextPlatinum.copy(alpha = 0.72f)
        )
    }
}

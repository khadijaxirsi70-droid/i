package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BoosterPreferencesRepository
import com.example.data.SafeSystemBridge
import com.example.model.BciArenaState
import com.example.model.BoosterScreen
import com.example.model.BoosterUiState
import com.example.model.DnsRouteNode
import com.example.model.NeuralSyncMode
import com.example.model.RadarBlip
import com.example.model.SafetyLogEntry
import com.example.model.TelemetrySample
import com.example.model.VoltageProfile
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BoosterViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = BoosterPreferencesRepository(application.applicationContext)
    val systemBridge = SafeSystemBridge(application.applicationContext)

    private val _uiState = MutableStateFlow(
        BoosterUiState(
            dnsNodes = defaultDnsNodes(),
            radarBlips = buildRadarBlips(defaultDnsNodes(), 60, 0.4f)
        )
    )
    val uiState: StateFlow<BoosterUiState> = _uiState.asStateFlow()

    private var aiCalibrationJob: Job? = null
    private var bciTestJob: Job? = null
    private var bciSignalShownAtNano: Long = 0L

    init {
        observeSavedSettings()
        initializeSafetyValveAndHardware()
        startFramePacingCollector()
        startPeriodicTelemetryLoop()
        scanQuantumDnsRoutes()
    }

    fun appendSafetyLog(entry: SafetyLogEntry) {
        _uiState.update { current ->
            val updated = (listOf(entry) + current.safetyLogs).take(30)
            current.copy(safetyLogs = updated)
        }
    }

    private fun observeSavedSettings() {
        viewModelScope.launch {
            prefsRepo.settingsFlow.collect { saved ->
                _uiState.update { state ->
                    val tunedVolt = computeTunedVoltage(
                        rawMv = state.rawBatteryVoltageMv,
                        nanoEnabled = saved.nanoThermalEnabled,
                        profile = saved.voltageProfile
                    )
                    val syncedLag = computeEffectiveInputLag(
                        jitterMs = state.frameJitterMs,
                        neuralEnabled = saved.neuralReflexEnabled,
                        mode = saved.neuralSyncMode,
                        hyperActive = saved.hyperBoostActive
                    )
                    val score = computeCoreScore(
                        hyper = saved.hyperBoostActive,
                        neural = saved.neuralReflexEnabled,
                        quantum = saved.quantumDnsEnabled,
                        thermal = saved.nanoThermalEnabled,
                        pingMs = state.effectivePingMs,
                        tempC = state.batteryTempCelsius
                    )
                    state.copy(
                        hyperBoostActive = saved.hyperBoostActive,
                        neuralReflexEnabled = saved.neuralReflexEnabled,
                        quantumDnsEnabled = saved.quantumDnsEnabled,
                        nanoThermalEnabled = saved.nanoThermalEnabled,
                        holographicHudEnabled = saved.holographicHudEnabled,
                        hudStealthScreenshotShield = saved.hudStealthScreenshotShield,
                        hudOpacity = saved.hudOpacity,
                        neuralSyncMode = saved.neuralSyncMode,
                        voltageProfile = saved.voltageProfile,
                        tunedVoltageMv = tunedVolt,
                        effectiveInputLagMs = syncedLag,
                        corePerformanceScore = score
                    )
                }
            }
        }
    }

    private fun initializeSafetyValveAndHardware() {
        val shizukuResult = systemBridge.probeShizukuPermission(::appendSafetyLog)
        val aiHardwareSupported = systemBridge.probe2030AiHardwareSupport(::appendSafetyLog)
        val hw = systemBridge.readSystemHardwareSnapshot(::appendSafetyLog)
        val thermal = systemBridge.readThermalAndBattery(::appendSafetyLog)

        _uiState.update { state ->
            val tunedVolt = computeTunedVoltage(
                rawMv = thermal.voltageMv,
                nanoEnabled = state.nanoThermalEnabled,
                profile = state.voltageProfile
            )
            state.copy(
                executionMode = shizukuResult.mode,
                shizukuStatusDetail = shizukuResult.statusDetail,
                isAiHardwareSupported = aiHardwareSupported,
                availableRamMb = hw.availableRamMb,
                totalRamMb = hw.totalRamMb,
                cpuCores = hw.cpuCores,
                displayRefreshRateHz = hw.displayRefreshHz,
                networkTransportLabel = hw.transportLabel,
                downstreamBandwidthMbps = hw.downstreamMbps,
                installedPubgPackage = hw.installedPubgPackage,
                batteryTempCelsius = thermal.temperatureCelsius,
                rawBatteryVoltageMv = thermal.voltageMv,
                tunedVoltageMv = tunedVolt,
                batteryPercent = thermal.batteryPercent
            )
        }

        if (!aiHardwareSupported) {
            triggerRandomizedAiCalibrationTimer()
        }
    }

    /**
     * Safety Valve Requirement #2:
     * When the device does not support the 2030 AI hardware model, runs a randomized timer
     * and shows the 'جاري معايرة الذكاء الاصطناعي' calibration alert banner.
     */
    fun triggerRandomizedAiCalibrationTimer() {
        aiCalibrationJob?.cancel()
        aiCalibrationJob = viewModelScope.launch {
            val randomDurationMs = Random.nextLong(2600L, 4600L)
            appendSafetyLog(
                systemBridge.createLogEntry(
                    subsystem = "AI-MOCK-TIMER",
                    detail = "جاري معايرة الذكاء الاصطناعي عبر المؤقت العشوائي (${randomDurationMs}ms)",
                    isSafetyFallback = true
                )
            )
            _uiState.update {
                it.copy(
                    isCalibratingAi = true,
                    aiCalibrationProgress = 0.08f,
                    aiCalibrationBannerVisible = true
                )
            }

            val steps = 20
            val stepDelay = randomDurationMs / steps
            for (step in 1..steps) {
                delay(stepDelay)
                _uiState.update {
                    it.copy(aiCalibrationProgress = (step.toFloat() / steps).coerceIn(0f, 1f))
                }
            }

            _uiState.update {
                it.copy(
                    isCalibratingAi = false,
                    aiCalibrationProgress = 1f,
                    aiLastCalibratedSecondsAgo = 0
                )
            }
            appendSafetyLog(
                systemBridge.createLogEntry(
                    subsystem = "AI-MOCK-TIMER",
                    detail = "اكتملت معايرة الذكاء الاصطناعي بنجاح وتحديث أوزان التنبؤ العصبي",
                    isSafetyFallback = false
                )
            )
        }
    }

    fun dismissAiCalibrationBanner() {
        _uiState.update { it.copy(aiCalibrationBannerVisible = false) }
    }

    fun recheckShizukuAndSafetyValve() {
        systemBridge.triggerHapticPulse(25L)
        val shizukuResult = systemBridge.probeShizukuPermission(::appendSafetyLog)
        _uiState.update {
            it.copy(
                executionMode = shizukuResult.mode,
                shizukuStatusDetail = shizukuResult.statusDetail
            )
        }
        if (!_uiState.value.isAiHardwareSupported) {
            triggerRandomizedAiCalibrationTimer()
        }
    }

    private fun startFramePacingCollector() {
        viewModelScope.launch {
            systemBridge.observeFramePacing(::appendSafetyLog).collect { pacing ->
                _uiState.update { state ->
                    val syncedLag = computeEffectiveInputLag(
                        jitterMs = pacing.jitterMs,
                        neuralEnabled = state.neuralReflexEnabled,
                        mode = state.neuralSyncMode,
                        hyperActive = state.hyperBoostActive
                    )
                    state.copy(
                        currentFps = pacing.fps,
                        frameJitterMs = pacing.jitterMs,
                        effectiveInputLagMs = syncedLag,
                        radarBlips = buildRadarBlips(state.dnsNodes, pacing.fps, syncedLag)
                    )
                }
            }
        }
    }

    private fun startPeriodicTelemetryLoop() {
        viewModelScope.launch {
            var tick = 0
            while (isActive) {
                val thermal = systemBridge.readThermalAndBattery(::appendSafetyLog)
                val hw = systemBridge.readSystemHardwareSnapshot(::appendSafetyLog)

                _uiState.update { state ->
                    val tunedVolt = computeTunedVoltage(
                        rawMv = thermal.voltageMv,
                        nanoEnabled = state.nanoThermalEnabled,
                        profile = state.voltageProfile
                    )
                    val sample = TelemetrySample(
                        tempCelsius = thermal.temperatureCelsius,
                        effectiveVoltageMv = tunedVolt,
                        fps = state.currentFps
                    )
                    val updatedHistory = (state.telemetryHistory + sample).takeLast(24)
                    val score = computeCoreScore(
                        hyper = state.hyperBoostActive,
                        neural = state.neuralReflexEnabled,
                        quantum = state.quantumDnsEnabled,
                        thermal = state.nanoThermalEnabled,
                        pingMs = state.effectivePingMs,
                        tempC = thermal.temperatureCelsius
                    )

                    state.copy(
                        batteryTempCelsius = thermal.temperatureCelsius,
                        rawBatteryVoltageMv = thermal.voltageMv,
                        tunedVoltageMv = tunedVolt,
                        batteryPercent = thermal.batteryPercent,
                        availableRamMb = hw.availableRamMb,
                        totalRamMb = hw.totalRamMb,
                        networkTransportLabel = hw.transportLabel,
                        downstreamBandwidthMbps = hw.downstreamMbps,
                        installedPubgPackage = hw.installedPubgPackage,
                        telemetryHistory = updatedHistory,
                        aiLastCalibratedSecondsAgo = state.aiLastCalibratedSecondsAgo + 2,
                        corePerformanceScore = score
                    )
                }

                tick++
                // Periodic randomized AI re-calibration pulse if AI hardware unsupported
                if (tick % 22 == 0 && !_uiState.value.isAiHardwareSupported && !_uiState.value.isCalibratingAi) {
                    triggerRandomizedAiCalibrationTimer()
                }
                delay(2000L)
            }
        }
    }

    fun scanQuantumDnsRoutes() {
        if (_uiState.value.isScanningDns) return
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningDns = true) }
            val nodes = systemBridge.probeQuantumDnsMultiPath(::appendSafetyLog)
            val weightedPing = if (nodes.isNotEmpty()) {
                val best = nodes.minOf { it.latencyMs }
                if (_uiState.value.quantumDnsEnabled) {
                    max(5, (best * 0.82f).roundToInt())
                } else {
                    best
                }
            } else {
                22
            }
            _uiState.update { state ->
                state.copy(
                    dnsNodes = nodes,
                    effectivePingMs = weightedPing,
                    isScanningDns = false,
                    radarBlips = buildRadarBlips(nodes, state.currentFps, state.effectiveInputLagMs)
                )
            }
        }
    }

    // Navigation
    fun selectScreen(screen: BoosterScreen) {
        systemBridge.triggerHapticPulse(14L)
        _uiState.update { it.copy(currentScreen = screen) }
    }

    // Master Hyper-Boost 2030 Ignition
    fun toggleHyperBoost() {
        val next = !_uiState.value.hyperBoostActive
        systemBridge.triggerHapticPulse(if (next) 45L else 20L)
        viewModelScope.launch {
            prefsRepo.updateBoolean("hyper_boost", next)
            if (next) {
                prefsRepo.updateBoolean("neural_reflex", true)
                prefsRepo.updateBoolean("quantum_dns", true)
                prefsRepo.updateBoolean("nano_thermal", true)
                systemBridge.optimizeAppMemorySafely(::appendSafetyLog)
                scanQuantumDnsRoutes()
                if (!_uiState.value.isAiHardwareSupported) {
                    triggerRandomizedAiCalibrationTimer()
                }
            }
        }
    }

    fun toggleNeuralReflex(enabled: Boolean) {
        systemBridge.triggerHapticPulse(20L)
        viewModelScope.launch { prefsRepo.updateBoolean("neural_reflex", enabled) }
    }

    fun toggleQuantumDns(enabled: Boolean) {
        systemBridge.triggerHapticPulse(20L)
        viewModelScope.launch {
            prefsRepo.updateBoolean("quantum_dns", enabled)
            if (enabled) scanQuantumDnsRoutes()
        }
    }

    fun toggleNanoThermal(enabled: Boolean) {
        systemBridge.triggerHapticPulse(20L)
        viewModelScope.launch { prefsRepo.updateBoolean("nano_thermal", enabled) }
    }

    fun toggleHolographicHud(enabled: Boolean) {
        systemBridge.triggerHapticPulse(24L)
        viewModelScope.launch { prefsRepo.updateBoolean("holographic_hud", enabled) }
    }

    fun toggleHudStealthShield(enabled: Boolean) {
        systemBridge.triggerHapticPulse(20L)
        viewModelScope.launch { prefsRepo.updateBoolean("hud_stealth", enabled) }
    }

    fun updateHudOpacity(opacity: Float) {
        viewModelScope.launch { prefsRepo.updateHudOpacity(opacity) }
    }

    fun resetHudPosition() {
        systemBridge.triggerHapticPulse(18L)
        _uiState.update { it.copy(hudResetTrigger = it.hudResetTrigger + 1) }
    }

    fun selectNeuralSyncMode(mode: NeuralSyncMode) {
        systemBridge.triggerHapticPulse(18L)
        viewModelScope.launch { prefsRepo.updateNeuralMode(mode) }
    }

    fun selectVoltageProfile(profile: VoltageProfile) {
        systemBridge.triggerHapticPulse(18L)
        viewModelScope.launch { prefsRepo.updateVoltageProfile(profile) }
    }

    fun launchGameWithBoost() {
        val pkg = _uiState.value.installedPubgPackage ?: return
        systemBridge.triggerHapticPulse(40L)
        if (!_uiState.value.hyperBoostActive) {
            toggleHyperBoost()
        }
        systemBridge.launchInstalledPubg(pkg, ::appendSafetyLog)
    }

    // Interactive BCI Reflex Zero-Lag Benchmark Arena
    fun startBciReflexTest() {
        bciTestJob?.cancel()
        systemBridge.triggerHapticPulse(20L)
        _uiState.update { it.copy(bciArenaState = BciArenaState.WAITING_FOR_PULSE) }
        bciTestJob = viewModelScope.launch {
            val waitDelay = Random.nextLong(1200L, 2900L)
            delay(waitDelay)
            bciSignalShownAtNano = System.nanoTime()
            systemBridge.triggerHapticPulse(30L)
            _uiState.update { it.copy(bciArenaState = BciArenaState.PULSE_READY) }
        }
    }

    fun onBciArenaTapped() {
        when (_uiState.value.bciArenaState) {
            BciArenaState.WAITING_FOR_PULSE -> {
                bciTestJob?.cancel()
                systemBridge.triggerHapticPulse(35L)
                _uiState.update { it.copy(bciArenaState = BciArenaState.TOO_EARLY) }
            }

            BciArenaState.PULSE_READY -> {
                val rawMs = ((System.nanoTime() - bciSignalShownAtNano) / 1_000_000f)
                    .coerceIn(45f, 999f)
                val state = _uiState.value
                // BCI predictive motion lead reduction down to near-zero residual frame delta
                val syncedResidualMs = if (state.neuralReflexEnabled) {
                    val factor = when (state.neuralSyncMode) {
                        NeuralSyncMode.TACTICAL -> 0.045f
                        NeuralSyncMode.HYPER_PREDICTIVE -> 0.022f
                        NeuralSyncMode.APEX_ZERO_LAG -> 0.004f
                    }
                    (rawMs * factor).coerceIn(0.1f, 12.0f)
                } else {
                    rawMs
                }
                systemBridge.triggerHapticPulse(25L)
                _uiState.update { current ->
                    val nextBest = current.bestSyncedDeltaMs?.let { minOf(it, syncedResidualMs) }
                        ?: syncedResidualMs
                    current.copy(
                        bciArenaState = BciArenaState.COMPLETED,
                        lastRawReflexMs = (rawMs * 10f).roundToInt() / 10f,
                        lastSyncedDeltaMs = (syncedResidualMs * 10f).roundToInt() / 10f,
                        bestSyncedDeltaMs = (nextBest * 10f).roundToInt() / 10f
                    )
                }
                appendSafetyLog(
                    systemBridge.createLogEntry(
                        subsystem = "BCI-REFLEX",
                        detail = "استجابة لمس خام ${"%.1f".format(rawMs)}ms -> مزامنة عصبية ${"%.1f".format(syncedResidualMs)}ms",
                        isSafetyFallback = false
                    )
                )
            }

            else -> startBciReflexTest()
        }
    }

    private fun computeTunedVoltage(
        rawMv: Int,
        nanoEnabled: Boolean,
        profile: VoltageProfile
    ): Int {
        return if (nanoEnabled) {
            (rawMv + profile.deltaMv).coerceAtLeast(3500)
        } else {
            rawMv
        }
    }

    private fun computeEffectiveInputLag(
        jitterMs: Float,
        neuralEnabled: Boolean,
        mode: NeuralSyncMode,
        hyperActive: Boolean
    ): Float {
        if (!neuralEnabled) {
            return ((8.4f + jitterMs) * 10f).roundToInt() / 10f
        }
        val base = (8.4f + jitterMs) - mode.leadCompensationMs
        val hyperBonus = if (hyperActive) 0.55f else 1.0f
        val effective = (base.coerceAtLeast(0.2f) * hyperBonus).coerceIn(0.1f, 9.9f)
        return (effective * 10f).roundToInt() / 10f
    }

    private fun computeCoreScore(
        hyper: Boolean,
        neural: Boolean,
        quantum: Boolean,
        thermal: Boolean,
        pingMs: Int,
        tempC: Float
    ): Int {
        var score = 74
        if (neural) score += 7
        if (quantum) score += 7
        if (thermal) score += 6
        if (hyper) score += 5
        if (pingMs > 60) score -= 5
        if (tempC > 43f) score -= 6
        return score.coerceIn(60, 99)
    }

    private fun defaultDnsNodes(): List<DnsRouteNode> = listOf(
        DnsRouteNode("cf_quantum", "Cloudflare Quantum", "1.1.1.1", "CF-EDGE-01", 16, 1, 38, true),
        DnsRouteNode("gg_hyper", "Google HyperDNS", "8.8.8.8", "GG-CORE-02", 21, 2, 29, true),
        DnsRouteNode("q9_shield", "Quad9 Anycast", "9.9.9.9", "Q9-NODE-03", 25, 2, 19, true),
        DnsRouteNode("od_neural", "OpenDNS Neural", "208.67.222.222", "OD-MESH-04", 29, 3, 14, true)
    )

    private fun buildRadarBlips(
        nodes: List<DnsRouteNode>,
        fps: Int,
        lagMs: Float
    ): List<RadarBlip> {
        val dnsBlips = nodes.mapIndexed { idx, node ->
            val angle = (35f + idx * 88f) % 360f
            val dist = (node.latencyMs / 85f).coerceIn(0.26f, 0.86f)
            val elev = (node.distributionPercent / 50f).coerceIn(0.25f, 0.95f)
            RadarBlip(
                id = node.id,
                code = node.clusterCode.take(6),
                azimuthDeg = angle,
                distanceNorm = dist,
                elevationNorm = elev,
                accentType = idx % 4,
                metricValue = "${node.latencyMs}ms"
            )
        }
        val bciBlip = RadarBlip(
            id = "bci_sync_core",
            code = "BCI-0",
            azimuthDeg = 310f,
            distanceNorm = 0.42f,
            elevationNorm = 0.92f,
            accentType = 3, // Molten Gold
            metricValue = "${lagMs}ms"
        )
        val fpsBlip = RadarBlip(
            id = "fps_lock",
            code = "FPS",
            azimuthDeg = 152f,
            distanceNorm = 0.58f,
            elevationNorm = (fps / 120f).coerceIn(0.4f, 1.0f),
            accentType = 0, // Neon Crimson
            metricValue = "$fps"
        )
        return dnsBlips + bciBlip + fpsBlip
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pure Obsidian 2030 Luxury Palette
val ObsidianBlack = Color(0xFF000000)
val ObsidianSurface = Color(0xFF07080F)
val ObsidianElevated = Color(0xFF0E101C)
val GlassWhiteTint = Color(0x14FFFFFF)
val GlassHighlight = Color(0x2EFFFFFF)
val GlassSubtleBorder = Color(0x1FFFFFFF)

// 4 Signature Luxury Neon Accents (Red, Blue, Purple, Golden Yellow)
val NeonCrimson = Color(0xFFFF2A54)
val NeonCrimsonDeep = Color(0xFFB80028)

val NeonQuantumBlue = Color(0xFF00E5FF)
val NeonElectricBlue = Color(0xFF2979FF)

val NeonCyberPurple = Color(0xFFA855F7)
val NeonDeepViolet = Color(0xFF6D28D9)

val NeonMoltenGold = Color(0xFFFFD60A)
val NeonAmberGold = Color(0xFFFF9E00)

// Telemetry & Text Hierarchy
val TextPlatinum = Color(0xFFF8FAFC)
val TextSilver = Color(0xFFCBD5E1)
val TextMutedSteel = Color(0xFF7E8BA3)
val TelemetryEmerald = Color(0xFF10B981)

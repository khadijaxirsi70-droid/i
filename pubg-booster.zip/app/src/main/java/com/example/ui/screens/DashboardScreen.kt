package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BoosterScreen
import com.example.model.BoosterUiState
import com.example.ui.components.AiCalibrationBanner
import com.example.ui.components.BoosterModuleCard
import com.example.ui.components.Radar3DCard
import com.example.ui.components.SafeModeStatusPill
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmberGold
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonElectricBlue
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.TelemetryEmerald
import com.example.ui.theme.TextPlatinum
import com.example.ui.theme.TextSilver

@Composable
fun DashboardScreen(
    uiState: BoosterUiState,
    isExpandedScreen: Boolean,
    onToggleHyperBoost: () -> Unit,
    onToggleNeural: (Boolean) -> Unit,
    onToggleQuantum: (Boolean) -> Unit,
    onToggleThermal: (Boolean) -> Unit,
    onToggleHud: (Boolean) -> Unit,
    onNavigateScreen: (BoosterScreen) -> Unit,
    onRecalibrateAi: () -> Unit,
    onDismissAiBanner: () -> Unit,
    onLaunchGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen_list")
    ) {
        // 1. Top 2030 Brand Header & Safe Mode Status Pill
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.header_edition_badge),
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = NeonMoltenGold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.headlineLarge,
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = TextPlatinum
                            )
                        }
                        Text(
                            text = stringResource(R.string.header_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSilver
                        )
                    }
                }

                SafeModeStatusPill(
                    executionMode = uiState.executionMode,
                    onInspectSafetyClick = { onNavigateScreen(BoosterScreen.THERMAL_SAFETY) }
                )

                AiCalibrationBanner(
                    visible = uiState.aiCalibrationBannerVisible,
                    isCalibrating = uiState.isCalibratingAi,
                    progress = uiState.aiCalibrationProgress,
                    onRecalibrateClick = onRecalibrateAi,
                    onDismissClick = onDismissAiBanner
                )
            }
        }

        // 2. Quantum Core Hero Banner + Master Hyper-Boost 2030 Ignition
        item {
            QuantumHeroIgnitionCard(
                uiState = uiState,
                onToggleHyperBoost = onToggleHyperBoost,
                onLaunchGame = onLaunchGame
            )
        }

        // 3. Adaptive Canonical Layout: Side-by-Side on Expanded Tablets, Stacked on Compact
        if (isExpandedScreen) {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Radar3DCard(
                        blips = uiState.radarBlips,
                        coreScore = uiState.corePerformanceScore,
                        fps = uiState.currentFps,
                        pingMs = uiState.effectivePingMs,
                        inputLagMs = uiState.effectiveInputLagMs,
                        tempCelsius = uiState.batteryTempCelsius,
                        hyperBoostActive = uiState.hyperBoostActive,
                        modifier = Modifier.weight(1f)
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        SuperFeaturesModuleList(
                            uiState = uiState,
                            onToggleNeural = onToggleNeural,
                            onToggleQuantum = onToggleQuantum,
                            onToggleThermal = onToggleThermal,
                            onToggleHud = onToggleHud,
                            onNavigateScreen = onNavigateScreen
                        )
                    }
                }
            }
        } else {
            item {
                Radar3DCard(
                    blips = uiState.radarBlips,
                    coreScore = uiState.corePerformanceScore,
                    fps = uiState.currentFps,
                    pingMs = uiState.effectivePingMs,
                    inputLagMs = uiState.effectiveInputLagMs,
                    tempCelsius = uiState.batteryTempCelsius,
                    hyperBoostActive = uiState.hyperBoostActive
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    SuperFeaturesModuleList(
                        uiState = uiState,
                        onToggleNeural = onToggleNeural,
                        onToggleQuantum = onToggleQuantum,
                        onToggleThermal = onToggleThermal,
                        onToggleHud = onToggleHud,
                        onNavigateScreen = onNavigateScreen
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun QuantumHeroIgnitionCard(
    uiState: BoosterUiState,
    onToggleHyperBoost: () -> Unit,
    onLaunchGame: () -> Unit
) {
    val pulse = rememberInfiniteTransition(label = "hyperPulse")
    val buttonScale by pulse.animateFloat(
        initialValue = 1.0f,
        targetValue = if (uiState.hyperBoostActive) 1.025f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hyperScale"
    )

    val borderAccent by animateColorAsState(
        targetValue = if (uiState.hyperBoostActive) NeonMoltenGold else NeonCyberPurple,
        label = "heroBorderAccent"
    )

    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(
                width = 1.4.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCrimson.copy(alpha = 0.75f),
                        borderAccent,
                        NeonQuantumBlue.copy(alpha = 0.75f),
                        NeonMoltenGold.copy(alpha = 0.85f)
                    )
                ),
                shape = shape
            )
    ) {
        // Generated 2030 Quantum Processor Visual Artwork Background
        Image(
            painter = painterResource(id = R.drawable.img_quantum_banner_1793621565183),
            contentDescription = stringResource(R.string.cd_quantum_banner),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .matchParentSize()
        )

        // Obsidian Glass Scrim for razor-sharp contrast
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianBlack.copy(alpha = 0.52f),
                            ObsidianBlack.copy(alpha = 0.80f),
                            ObsidianBlack.copy(alpha = 0.94f)
                        )
                    )
                )
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "${uiState.cpuCores} أنوية • ${uiState.displayRefreshRateHz}Hz • ${uiState.availableRamMb}MB متاح",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = NeonQuantumBlue
                )
                Text(
                    text = uiState.networkTransportLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonMoltenGold
                )
            }

            Text(
                text = if (uiState.installedPubgPackage != null) {
                    stringResource(R.string.pubg_status_installed)
                } else {
                    stringResource(R.string.pubg_status_standby)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = TextPlatinum
            )

            Button(
                onClick = onToggleHyperBoost,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = ObsidianBlack
                ),
                contentPadding = PaddingValues(0.dp),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .scale(buttonScale)
                    .testTag("master_hyper_boost_button")
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (uiState.hyperBoostActive) {
                                Brush.horizontalGradient(
                                    colors = listOf(NeonMoltenGold, NeonAmberGold, NeonCrimson)
                                )
                            } else {
                                Brush.horizontalGradient(
                                    colors = listOf(NeonQuantumBlue, NeonCyberPurple, NeonCrimson)
                                )
                            }
                        )
                        .padding(vertical = 14.dp, horizontal = 16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = null,
                            tint = if (uiState.hyperBoostActive) ObsidianBlack else TextPlatinum,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.hyperBoostActive) {
                                stringResource(R.string.btn_hyper_boost_active)
                            } else {
                                stringResource(R.string.btn_hyper_boost_activate)
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.hyperBoostActive) ObsidianBlack else TextPlatinum
                        )
                    }
                }
            }

            if (uiState.installedPubgPackage != null) {
                OutlinedButton(
                    onClick = onLaunchGame,
                    border = ButtonDefaults.outlinedButtonBorder(enabled = true),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("launch_pubg_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SportsEsports,
                        contentDescription = null,
                        tint = TelemetryEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_launch_game),
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPlatinum
                    )
                }
            }
        }
    }
}

@Composable
private fun SuperFeaturesModuleList(
    uiState: BoosterUiState,
    onToggleNeural: (Boolean) -> Unit,
    onToggleQuantum: (Boolean) -> Unit,
    onToggleThermal: (Boolean) -> Unit,
    onToggleHud: (Boolean) -> Unit,
    onNavigateScreen: (BoosterScreen) -> Unit
) {
    // 1. Neural Reflex Sync (Golden Yellow + Crimson)
    BoosterModuleCard(
        title = stringResource(R.string.feature_neural_title),
        description = stringResource(R.string.feature_neural_desc),
        metricBadge = "INPUT LAG: ${uiState.effectiveInputLagMs}ms",
        subMetricBadge = "${uiState.neuralSyncMode.arabicLabel} • ${if (uiState.executionMode.name == "SAFE_MODE") "الوضع الآمن" else "Shizuku"}",
        icon = Icons.Filled.Psychology,
        primaryAccent = NeonMoltenGold,
        secondaryAccent = NeonCrimson,
        enabled = uiState.neuralReflexEnabled,
        onToggle = onToggleNeural,
        onOpenDetails = { onNavigateScreen(BoosterScreen.NEURAL_QUANTUM) },
        cardTag = "card_neural_reflex",
        switchTag = "switch_neural_reflex"
    )

    // 2. Quantum DNS Routing (Quantum Blue + Cyber Purple)
    BoosterModuleCard(
        title = stringResource(R.string.feature_quantum_title),
        description = stringResource(R.string.feature_quantum_desc),
        metricBadge = "PING: ${uiState.effectivePingMs}ms • 4 مسارات",
        subMetricBadge = if (uiState.isCalibratingAi) "جاري معايرة الذكاء الاصطناعي..." else "توزيع متعدد المسارات متزامن",
        icon = Icons.Filled.Hub,
        primaryAccent = NeonQuantumBlue,
        secondaryAccent = NeonElectricBlue,
        enabled = uiState.quantumDnsEnabled,
        onToggle = onToggleQuantum,
        onOpenDetails = { onNavigateScreen(BoosterScreen.NEURAL_QUANTUM) },
        cardTag = "card_quantum_dns",
        switchTag = "switch_quantum_dns"
    )

    // 3. Nano-Thermal Shield (Crimson Red + Molten Gold)
    BoosterModuleCard(
        title = stringResource(R.string.feature_thermal_title),
        description = stringResource(R.string.feature_thermal_desc),
        metricBadge = "${"%.1f".format(uiState.batteryTempCelsius)}°C • ${uiState.tunedVoltageMv}mV",
        subMetricBadge = uiState.voltageProfile.arabicLabel,
        icon = Icons.Filled.DeviceThermostat,
        primaryAccent = NeonCrimson,
        secondaryAccent = NeonMoltenGold,
        enabled = uiState.nanoThermalEnabled,
        onToggle = onToggleThermal,
        onOpenDetails = { onNavigateScreen(BoosterScreen.THERMAL_SAFETY) },
        cardTag = "card_nano_thermal",
        switchTag = "switch_nano_thermal"
    )

    // 4. Holographic HUD (Cyber Purple + Quantum Blue)
    BoosterModuleCard(
        title = stringResource(R.string.feature_hud_title),
        description = stringResource(R.string.feature_hud_desc),
        metricBadge = if (uiState.hudStealthScreenshotShield) {
            "STEALTH FLAG_SECURE • ${(uiState.hudOpacity * 100).toInt()}%"
        } else {
            "شفافية ${(uiState.hudOpacity * 100).toInt()}%"
        },
        subMetricBadge = if (uiState.holographicHudEnabled) "لوحة الهولوغرام العائمة نشطة" else "اضغط للتفعيل الفوري على الشاشة",
        icon = Icons.Filled.ViewInAr,
        primaryAccent = NeonCyberPurple,
        secondaryAccent = NeonQuantumBlue,
        enabled = uiState.holographicHudEnabled,
        onToggle = onToggleHud,
        onOpenDetails = { onNavigateScreen(BoosterScreen.THERMAL_SAFETY) },
        cardTag = "card_holographic_hud",
        switchTag = "switch_holographic_hud"
    )
}

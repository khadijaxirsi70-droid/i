package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val Obsidian2030ColorScheme = darkColorScheme(
    primary = NeonQuantumBlue,
    onPrimary = ObsidianBlack,
    primaryContainer = ObsidianElevated,
    onPrimaryContainer = NeonQuantumBlue,
    secondary = NeonCyberPurple,
    onSecondary = TextPlatinum,
    secondaryContainer = ObsidianElevated,
    onSecondaryContainer = NeonCyberPurple,
    tertiary = NeonMoltenGold,
    onTertiary = ObsidianBlack,
    tertiaryContainer = ObsidianElevated,
    onTertiaryContainer = NeonMoltenGold,
    error = NeonCrimson,
    onError = TextPlatinum,
    background = ObsidianBlack,
    onBackground = TextPlatinum,
    surface = ObsidianSurface,
    onSurface = TextPlatinum,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = TextSilver,
    outline = GlassSubtleBorder
)

val BoosterShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun PubgBoosterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = Obsidian2030ColorScheme,
        typography = Typography,
        shapes = BoosterShapes,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    PubgBoosterTheme(content = content)
}

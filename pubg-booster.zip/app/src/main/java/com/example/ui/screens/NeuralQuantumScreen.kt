package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BciArenaState
import com.example.model.BoosterUiState
import com.example.model.DnsRouteNode
import com.example.model.NeuralSyncMode
import com.example.ui.components.AiCalibrationBanner
import com.example.ui.components.ObsidianGlassCard
import com.example.ui.components.TelemetryStatChip
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TelemetryEmerald
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPlatinum
import com.example.ui.theme.TextSilver

@Composable
fun NeuralQuantumScreen(
    uiState: BoosterUiState,
    onBackToDashboard: () -> Unit,
    onSelectNeuralMode: (NeuralSyncMode) -> Unit,
    onBciArenaTap: () -> Unit,
    onScanQuantumDns: () -> Unit,
    onRecalibrateAi: () -> Unit,
    onDismissAiBanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToDashboard)

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("neural_quantum_screen_list")
    ) {
        item {
            AiCalibrationBanner(
                visible = uiState.aiCalibrationBannerVisible,
                isCalibrating = uiState.isCalibratingAi,
                progress = uiState.aiCalibrationProgress,
                onRecalibrateClick = onRecalibrateAi,
                onDismissClick = onDismissAiBanner
            )
        }

        // Section 1: Neural Reflex Sync (BCI Simulation & Zero-Lag Frame Pacing)
        item {
            ObsidianGlassCard(
                primaryAccent = NeonMoltenGold,
                secondaryAccent = NeonCrimson,
                isHighlighted = uiState.neuralReflexEnabled
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Psychology,
                        contentDescription = null,
                        tint = NeonMoltenGold,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = stringResource(R.string.feature_neural_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPlatinum
                        )
                        Text(
                            text = "مزامنة Choreographer الحية • تذبذب الإطارات ${uiState.frameJitterMs}ms",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonMoltenGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mode selector chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    NeuralSyncMode.entries.forEach { mode ->
                        val selected = uiState.neuralSyncMode == mode
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectNeuralMode(mode) },
                            label = {
                                Text(
                                    text = mode.arabicLabel,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonMoltenGold.copy(alpha = 0.22f),
                                selectedLabelColor = NeonMoltenGold,
                                containerColor = Color.White.copy(alpha = 0.05f),
                                labelColor = TextSilver
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("neural_mode_${mode.name.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TelemetryStatChip(
                        label = "تأخير BCI الفعال",
                        value = "${uiState.effectiveInputLagMs}ms",
                        accent = NeonMoltenGold,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatChip(
                        label = "معدل العرض",
                        value = "${uiState.displayRefreshRateHz}Hz",
                        accent = NeonQuantumBlue,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatChip(
                        label = "أفضل استجابة",
                        value = uiState.bestSyncedDeltaMs?.let { "${it}ms" } ?: "--",
                        accent = TelemetryEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive BCI Reflex Arena Pad
                BciReflexArenaBox(
                    arenaState = uiState.bciArenaState,
                    lastRawMs = uiState.lastRawReflexMs,
                    lastSyncedMs = uiState.lastSyncedDeltaMs,
                    onTap = onBciArenaTap
                )
            }
        }

        // Section 2: Quantum DNS Multi-Path Routing
        item {
            ObsidianGlassCard(
                primaryAccent = NeonQuantumBlue,
                secondaryAccent = NeonCyberPurple,
                isHighlighted = uiState.quantumDnsEnabled
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Hub,
                        contentDescription = null,
                        tint = NeonQuantumBlue,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.quantum_routes_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPlatinum
                        )
                        Text(
                            text = "${uiState.networkTransportLabel} • عرض النطاق ${uiState.downstreamBandwidthMbps} Mbps",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonQuantumBlue
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    uiState.dnsNodes.forEachIndexed { idx, node ->
                        QuantumDnsNodeRow(node = node, rankIndex = idx)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onScanQuantumDns,
                        enabled = !uiState.isScanningDns,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonQuantumBlue,
                            contentColor = ObsidianBlack
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("scan_quantum_dns_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NetworkCheck,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (uiState.isScanningDns) {
                                "جاري الفحص..."
                            } else {
                                stringResource(R.string.btn_scan_quantum_dns)
                            },
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    OutlinedButton(
                        onClick = onRecalibrateAi,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("recalibrate_ai_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = NeonMoltenGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.btn_recalibrate_ai),
                            style = MaterialTheme.typography.labelLarge,
                            color = NeonMoltenGold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun BciReflexArenaBox(
    arenaState: BciArenaState,
    lastRawMs: Float?,
    lastSyncedMs: Float?,
    onTap: () -> Unit
) {
    val padAccent by animateColorAsState(
        targetValue = when (arenaState) {
            BciArenaState.IDLE -> NeonCyberPurple
            BciArenaState.WAITING_FOR_PULSE -> NeonCrimson
            BciArenaState.PULSE_READY -> NeonMoltenGold
            BciArenaState.COMPLETED -> TelemetryEmerald
            BciArenaState.TOO_EARLY -> NeonCrimson
        },
        label = "bciPadColor"
    )

    val shape = RoundedCornerShape(20.dp)
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(shape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        padAccent.copy(alpha = if (arenaState == BciArenaState.PULSE_READY) 0.42f else 0.18f),
                        ObsidianBlack.copy(alpha = 0.88f)
                    )
                )
            )
            .border(width = 1.5.dp, color = padAccent.copy(alpha = 0.72f), shape = shape)
            .clickable(onClick = onTap)
            .padding(16.dp)
            .testTag("bci_reflex_pad")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.TouchApp,
                contentDescription = stringResource(R.string.bci_arena_title),
                tint = padAccent,
                modifier = Modifier.size(30.dp)
            )
            Text(
                text = when (arenaState) {
                    BciArenaState.IDLE -> stringResource(R.string.bci_start_test)
                    BciArenaState.WAITING_FOR_PULSE -> stringResource(R.string.bci_wait_signal)
                    BciArenaState.PULSE_READY -> stringResource(R.string.bci_tap_now)
                    BciArenaState.TOO_EARLY -> "نبضة مبكرة! اضغط لإعادة الاختبار العصبي"
                    BciArenaState.COMPLETED ->
                        "زمن اللمس الخام ${lastRawMs}ms ⟵ بعد التنبؤ العصبي ${lastSyncedMs}ms"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPlatinum,
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(R.string.bci_arena_subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = TextSilver,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun QuantumDnsNodeRow(
    node: DnsRouteNode,
    rankIndex: Int
) {
    val nodeAccent = when (rankIndex % 4) {
        0 -> NeonQuantumBlue
        1 -> NeonMoltenGold
        2 -> NeonCyberPurple
        else -> NeonCrimson
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.04f))
            .border(
                width = 1.dp,
                color = nodeAccent.copy(alpha = 0.28f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = node.providerName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPlatinum
                )
                Text(
                    text = "${node.ipAddress} • ${node.clusterCode}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = TextMutedSteel
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${node.latencyMs}ms (±${node.jitterMs}ms)",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = nodeAccent
                )
                Text(
                    text = "حصة المسار ${node.distributionPercent}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSilver
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = { (node.distributionPercent / 100f).coerceIn(0.05f, 1f) },
            color = nodeAccent,
            trackColor = Color.White.copy(alpha = 0.08f),
            strokeCap = StrokeCap.Round,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(50))
        )
    }
}

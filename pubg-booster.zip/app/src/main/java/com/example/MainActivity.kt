package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.BoosterScreen
import com.example.ui.BoosterViewModel
import com.example.ui.components.HolographicHudOverlay
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NeuralQuantumScreen
import com.example.ui.screens.ThermalSafetyScreen
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.NeonCyberPurple
import com.example.ui.theme.NeonMoltenGold
import com.example.ui.theme.NeonQuantumBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.PubgBoosterTheme
import com.example.ui.theme.TextMutedSteel
import com.example.ui.theme.TextPlatinum

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            PubgBoosterTheme {
                val boosterViewModel: BoosterViewModel = viewModel()
                val uiState by boosterViewModel.uiState.collectAsStateWithLifecycle()

                // Dynamically apply or clear Android FLAG_SECURE screenshot stealth protection
                // wrapped inside try-catch via SafeSystemBridge
                LaunchedEffect(uiState.holographicHudEnabled, uiState.hudStealthScreenshotShield) {
                    val shouldHideFromScreenshots =
                        uiState.holographicHudEnabled && uiState.hudStealthScreenshotShield
                    boosterViewModel.systemBridge.applyScreenshotStealthFlag(
                        activity = this@MainActivity,
                        stealthActive = shouldHideFromScreenshots,
                        onLog = boosterViewModel::appendSafetyLog
                    )
                }

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PubgBoosterAppShell(boosterViewModel = boosterViewModel)
                }
            }
        }
    }
}

private data class NavDestinationItem(
    val screen: BoosterScreen,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val accent: Color,
    val tag: String
)

@Composable
fun PubgBoosterAppShell(
    boosterViewModel: BoosterViewModel
) {
    val uiState by boosterViewModel.uiState.collectAsStateWithLifecycle()

    val navItems = listOf(
        NavDestinationItem(
            screen = BoosterScreen.DASHBOARD,
            labelRes = R.string.nav_dashboard,
            selectedIcon = Icons.Filled.Dashboard,
            unselectedIcon = Icons.Outlined.Dashboard,
            accent = NeonQuantumBlue,
            tag = "nav_tab_dashboard"
        ),
        NavDestinationItem(
            screen = BoosterScreen.NEURAL_QUANTUM,
            selectedIcon = Icons.Filled.Hub,
            unselectedIcon = Icons.Outlined.Hub,
            labelRes = R.string.nav_neural_quantum,
            accent = NeonMoltenGold,
            tag = "nav_tab_neural_quantum"
        ),
        NavDestinationItem(
            screen = BoosterScreen.THERMAL_SAFETY,
            selectedIcon = Icons.Filled.Shield,
            unselectedIcon = Icons.Outlined.Shield,
            labelRes = R.string.nav_thermal_safety,
            accent = NeonCrimson,
            tag = "nav_tab_thermal_safety"
        )
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .drawBehind {
                // Subtle luxury ambient neon nebula corners on pure #000000 Obsidian Black
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonCyberPurple.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.88f, size.height * 0.08f),
                        radius = size.width * 0.65f
                    ),
                    radius = size.width * 0.65f,
                    center = Offset(size.width * 0.88f, size.height * 0.08f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonQuantumBlue.copy(alpha = 0.09f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.12f, size.height * 0.45f),
                        radius = size.width * 0.55f
                    ),
                    radius = size.width * 0.55f,
                    center = Offset(size.width * 0.12f, size.height * 0.45f)
                )
            }
    ) {
        val isExpanded = maxWidth >= 840.dp

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!isExpanded) {
                    NavigationBar(
                        containerColor = ObsidianSurface.copy(alpha = 0.92f),
                        tonalElevation = 0.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 0.8.dp,
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        NeonCrimson.copy(alpha = 0.35f),
                                        NeonQuantumBlue.copy(alpha = 0.45f),
                                        NeonCyberPurple.copy(alpha = 0.35f),
                                        NeonMoltenGold.copy(alpha = 0.40f)
                                    )
                                ),
                                shape = MaterialTheme.shapes.extraSmall
                            )
                    ) {
                        navItems.forEach { item ->
                            val selected = uiState.currentScreen == item.screen
                            NavigationBarItem(
                                selected = selected,
                                onClick = { boosterViewModel.selectScreen(item.screen) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = item.accent,
                                    indicatorColor = item.accent,
                                    unselectedIconColor = TextMutedSteel,
                                    unselectedTextColor = TextMutedSteel
                                ),
                                modifier = Modifier.testTag(item.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpanded) {
                    NavigationRail(
                        containerColor = ObsidianSurface.copy(alpha = 0.88f),
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        navItems.forEach { item ->
                            val selected = uiState.currentScreen == item.screen
                            NavigationRailItem(
                                selected = selected,
                                onClick = { boosterViewModel.selectScreen(item.screen) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = item.accent,
                                    indicatorColor = item.accent,
                                    unselectedIconColor = TextPlatinum.copy(alpha = 0.6f),
                                    unselectedTextColor = TextMutedSteel
                                ),
                                modifier = Modifier.testTag(item.tag)
                            )
                        }
                    }
                }

                Crossfade(
                    targetState = uiState.currentScreen,
                    label = "screenCrossfade",
                    modifier = Modifier.weight(1f)
                ) { targetScreen ->
                    when (targetScreen) {
                        BoosterScreen.DASHBOARD -> DashboardScreen(
                            uiState = uiState,
                            isExpandedScreen = isExpanded,
                            onToggleHyperBoost = boosterViewModel::toggleHyperBoost,
                            onToggleNeural = boosterViewModel::toggleNeuralReflex,
                            onToggleQuantum = boosterViewModel::toggleQuantumDns,
                            onToggleThermal = boosterViewModel::toggleNanoThermal,
                            onToggleHud = boosterViewModel::toggleHolographicHud,
                            onNavigateScreen = boosterViewModel::selectScreen,
                            onRecalibrateAi = boosterViewModel::triggerRandomizedAiCalibrationTimer,
                            onDismissAiBanner = boosterViewModel::dismissAiCalibrationBanner,
                            onLaunchGame = boosterViewModel::launchGameWithBoost
                        )

                        BoosterScreen.NEURAL_QUANTUM -> NeuralQuantumScreen(
                            uiState = uiState,
                            onBackToDashboard = {
                                boosterViewModel.selectScreen(BoosterScreen.DASHBOARD)
                            },
                            onSelectNeuralMode = boosterViewModel::selectNeuralSyncMode,
                            onBciArenaTap = boosterViewModel::onBciArenaTapped,
                            onScanQuantumDns = boosterViewModel::scanQuantumDnsRoutes,
                            onRecalibrateAi = boosterViewModel::triggerRandomizedAiCalibrationTimer,
                            onDismissAiBanner = boosterViewModel::dismissAiCalibrationBanner
                        )

                        BoosterScreen.THERMAL_SAFETY -> ThermalSafetyScreen(
                            uiState = uiState,
                            onBackToDashboard = {
                                boosterViewModel.selectScreen(BoosterScreen.DASHBOARD)
                            },
                            onSelectVoltageProfile = boosterViewModel::selectVoltageProfile,
                            onToggleHud = boosterViewModel::toggleHolographicHud,
                            onToggleHudStealth = boosterViewModel::toggleHudStealthShield,
                            onChangeHudOpacity = boosterViewModel::updateHudOpacity,
                            onResetHudPosition = boosterViewModel::resetHudPosition,
                            onRecheckSafetyValve = boosterViewModel::recheckShizukuAndSafetyValve
                        )
                    }
                }
            }
        }

        // Floating Transparent Holographic HUD Layer
        HolographicHudOverlay(
            visible = uiState.holographicHudEnabled,
            opacity = uiState.hudOpacity,
            stealthScreenshotActive = uiState.hudStealthScreenshotShield,
            resetTrigger = uiState.hudResetTrigger,
            fps = uiState.currentFps,
            pingMs = uiState.effectivePingMs,
            inputLagMs = uiState.effectiveInputLagMs,
            tempCelsius = uiState.batteryTempCelsius,
            voltageMv = uiState.tunedVoltageMv,
            onCloseHud = { boosterViewModel.toggleHolographicHud(false) },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 12.dp)
        )
    }
}
